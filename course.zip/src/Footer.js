import React from 'react'

function Footer() {
  return (
    <div>
      {/* <!-- Footer--> */}
        <footer class="footer bg-light small text-center text-black-50"><div class="container px-4 px-lg-5">Copyright &copy; KMUTNB MOOC | งานดิจิทัลเทคโนโลยี ฝ่ายพัฒนาระบบสารสนเทศ สำนักพัฒนาเทคนิคศึกษา มจพ.</div></footer>
    </div>
  )
}

export default Footer
